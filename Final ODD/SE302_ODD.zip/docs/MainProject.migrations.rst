MainProject.migrations package
==============================

Submodules
----------

MainProject.migrations.0001\_initial module
-------------------------------------------

.. automodule:: MainProject.migrations.0001_initial
    :members:
    :undoc-members:
    :show-inheritance:

MainProject.migrations.0002\_auto\_20190307\_1806 module
--------------------------------------------------------

.. automodule:: MainProject.migrations.0002_auto_20190307_1806
    :members:
    :undoc-members:
    :show-inheritance:

MainProject.migrations.0002\_comments module
--------------------------------------------

.. automodule:: MainProject.migrations.0002_comments
    :members:
    :undoc-members:
    :show-inheritance:

MainProject.migrations.0003\_auto\_20181230\_1534 module
--------------------------------------------------------

.. automodule:: MainProject.migrations.0003_auto_20181230_1534
    :members:
    :undoc-members:
    :show-inheritance:

MainProject.migrations.0003\_auto\_20190311\_2013 module
--------------------------------------------------------

.. automodule:: MainProject.migrations.0003_auto_20190311_2013
    :members:
    :undoc-members:
    :show-inheritance:

MainProject.migrations.0004\_auto\_20181230\_1536 module
--------------------------------------------------------

.. automodule:: MainProject.migrations.0004_auto_20181230_1536
    :members:
    :undoc-members:
    :show-inheritance:

MainProject.migrations.0004\_clubs\_fav module
----------------------------------------------

.. automodule:: MainProject.migrations.0004_clubs_fav
    :members:
    :undoc-members:
    :show-inheritance:

MainProject.migrations.0005\_auto\_20181231\_0004 module
--------------------------------------------------------

.. automodule:: MainProject.migrations.0005_auto_20181231_0004
    :members:
    :undoc-members:
    :show-inheritance:

MainProject.migrations.0005\_auto\_20190416\_1305 module
--------------------------------------------------------

.. automodule:: MainProject.migrations.0005_auto_20190416_1305
    :members:
    :undoc-members:
    :show-inheritance:

MainProject.migrations.0006\_auto\_20181231\_0051 module
--------------------------------------------------------

.. automodule:: MainProject.migrations.0006_auto_20181231_0051
    :members:
    :undoc-members:
    :show-inheritance:

MainProject.migrations.0006\_auto\_20190424\_1838 module
--------------------------------------------------------

.. automodule:: MainProject.migrations.0006_auto_20190424_1838
    :members:
    :undoc-members:
    :show-inheritance:

MainProject.migrations.0007\_auto\_20190101\_1454 module
--------------------------------------------------------

.. automodule:: MainProject.migrations.0007_auto_20190101_1454
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: MainProject.migrations
    :members:
    :undoc-members:
    :show-inheritance:
