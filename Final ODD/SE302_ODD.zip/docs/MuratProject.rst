MuratProject package
====================

Submodules
----------

MuratProject.settings module
----------------------------

.. automodule:: MuratProject.settings
    :members:
    :undoc-members:
    :show-inheritance:

MuratProject.urls module
------------------------

.. automodule:: MuratProject.urls
    :members:
    :undoc-members:
    :show-inheritance:

MuratProject.wsgi module
------------------------

.. automodule:: MuratProject.wsgi
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: MuratProject
    :members:
    :undoc-members:
    :show-inheritance:
