.. automodule:: MainProject.urls
    :members:
    :undoc-members:
    :show-inheritance:
	
.. automodule:: MainProject.views
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: MainProject.models
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: MainProject.forms
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: MainProject
    :members:
    :undoc-members:
    :show-inheritance:	